global using static ECommons.GenericHelpers;
