﻿namespace NecroLens.Model;

public enum DeepDungeonTrapStatus
{
    Active,
    Visible,
    Inactive
}
