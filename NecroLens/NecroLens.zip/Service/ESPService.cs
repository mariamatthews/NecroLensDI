using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Threading;
using SystemTask = System.Threading.Tasks.Task;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.Enums;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Plugin.Services;
using ImGuiNET;
using Lumina.Excel.Sheets;
using NecroLens.Interface;
using NecroLens.Model;
using NecroLens.util;
using static FFXIVClientStructs.FFXIV.Client.UI.UI3DModule;
using static NecroLens.util.ESPUtils;
using Dalamud.IoC;
using FFXIVClientStructs.FFXIV.Client.System.Framework;


namespace NecroLens.Service;

public class ESPService : IDisposable
{
    private const ushort Tick = 250;
    private readonly ILoggingService logger;
    private readonly IClientState clientState;
    private readonly Configuration configuration;
    private readonly IObjectTable objectTable;
    private readonly IDeepDungeonService deepDungeonService;
    private readonly IFramework framework;
    private readonly IMobInfoService mobInfoService;

    [PluginService] public IFramework Framework { get; private set; } = null!;

    private readonly List<ESPObject> mapObjects = new List<ESPObject>();
    private readonly SystemTask mapScanner;
    private bool active;

    public ESPService(ILoggingService logger,
        Configuration configuration,
        IMainUIManager mainUIManager,
        IClientState clientState,
        IObjectTable objectTable,
        IDeepDungeonService deepDungeonService,
        IFramework framework,
        IMobInfoService mobInfoService)
    {
        try
        {
            this.logger = logger;
            logger.LogDebug("ESP Service loading...");
            this.clientState = clientState;
            this.objectTable = objectTable;
            this.deepDungeonService = deepDungeonService;
            this.configuration = configuration;
            this.framework = framework;
            this.mobInfoService = mobInfoService;


            active = true;

            NecroLens.PluginInterface.UiBuilder.Draw += OnUpdate;
            NecroLens.ClientState.TerritoryChanged += OnCleanup;

            // Enable Scanner
            this.mapScanner = SystemTask.Run(MapScanner);
        }
        catch (Exception e)
        {
            logger.LogError(e.ToString());
        }
    }

    public void Dispose()
    {
        try
        {
            NecroLens.PluginInterface.UiBuilder.Draw -= OnUpdate;
            NecroLens.ClientState.TerritoryChanged -= OnCleanup;
            active = false;
            while (!mapScanner.IsCompleted) logger.LogDebug("wait till scanner is stopped...");
            mapObjects.Clear();
            NecroLens.PluginLog.Information("ESP Service unloaded");
        }
        catch (Exception e)
        {
            NecroLens.PluginLog.Error(e.ToString());
        }
    }

    /**
     * Clears the drawable GameObjects on MapChange.
     */
    private void OnCleanup(ushort e)
    {
        try
        {
            // Example inside your scanning or drawing loop:
            lock (mapObjects)
            {
                mapObjects.RemoveAll(obj => !obj.GameObject.IsValid());
            }
        }
        catch (Exception ex)
        {
            NecroLens.PluginLog.Error(ex.ToString());
        }
    }

    /**
     * Main-Drawing method.
     */
    private void OnUpdate()
    {
        try
        {
            if (ShouldDraw())
            {
                if (!Monitor.TryEnter(mapObjects)) return;

                var drawList = ImGui.GetBackgroundDrawList();
                foreach (var gameObject in mapObjects) DrawEspObject(drawList, gameObject);

                Monitor.Exit(mapObjects);
            }
        }
        catch (Exception e)
        {
            NecroLens.PluginLog.Error(e.ToString());
        }
    }

    private bool DoDrawName(ESPObject espObject)
    {
        return espObject.Type switch
        {
            ESPObject.ESPType.Player => false,
            ESPObject.ESPType.Enemy => !espObject.InCombat(),
            ESPObject.ESPType.Mimic => !espObject.InCombat(),
            ESPObject.ESPType.FriendlyEnemy => !espObject.InCombat(),
            ESPObject.ESPType.BronzeChest => configuration.ShowBronzeCoffers,
            ESPObject.ESPType.SilverChest => configuration.ShowSilverCoffers,
            ESPObject.ESPType.GoldChest => configuration.ShowGoldCoffers,
            ESPObject.ESPType.AccursedHoard => configuration.ShowHoards && !NecroLens.DeepDungeonService.FloorDetails.HoardFound,
            ESPObject.ESPType.MimicChest => configuration.ShowMimicCoffer,
            ESPObject.ESPType.Trap => configuration.ShowTraps,
            ESPObject.ESPType.Return => configuration.ShowReturn,
            ESPObject.ESPType.Passage => configuration.ShowPassage,
            _ => false
        };
    }

    /**
     * Draws every Object for the ESP-Overlay.
     */
    private void DrawEspObject(ImDrawListPtr drawList, ESPObject espObject)
    {
        try
        {
            if (!espObject.GameObject.IsValid())
                return;

            var type = espObject.Type;
            var onScreen = NecroLens.GameGui.WorldToScreen(espObject.GameObject.Position, out var position2D);
            if (onScreen)
            {
                var distance = espObject.Distance();

                if (configuration.ShowPlayerDot && type == ESPObject.ESPType.Player)
                    DrawPlayerDot(drawList, position2D, configuration); // Pass the configuration parameter

                if (DoDrawName(espObject))
                    DrawName(drawList, espObject, position2D);

                if (espObject.Type == ESPObject.ESPType.AccursedHoard && configuration.ShowHoards && !NecroLens.DeepDungeonService.FloorDetails.HoardFound)
                {
                    var chestRadius = type == ESPObject.ESPType.AccursedHoard ? 2.0f : 1f; // Make Hoards bigger

                    if (distance <= 35 && configuration.HighlightCoffers)
                        DrawCircleFilled(drawList, espObject, chestRadius, espObject.RenderColor(), 1f);
                }

                if (espObject.IsChest())
                {
                    if (!configuration.ShowBronzeCoffers && type == ESPObject.ESPType.BronzeChest) return;
                    if (!configuration.ShowSilverCoffers && type == ESPObject.ESPType.SilverChest) return;
                    if (!configuration.ShowGoldCoffers && type == ESPObject.ESPType.GoldChest) return;
                    if (!configuration.ShowHoards && type == ESPObject.ESPType.AccursedHoardCoffer) return;

                    if (distance <= 35 && configuration.HighlightCoffers)
                        DrawCircleFilled(drawList, espObject, 1f, espObject.RenderColor(), 1f);
                    if (distance <= 10 && configuration.ShowCofferInteractionRange)
                        DrawInteractionCircle(drawList, espObject, espObject.InteractionDistance());
                }

                if (configuration.ShowTraps && type == ESPObject.ESPType.Trap)
                    DrawCircleFilled(drawList, espObject, 1.7f, espObject.RenderColor());

                if (configuration.ShowMimicCoffer && type == ESPObject.ESPType.MimicChest)
                    DrawCircleFilled(drawList, espObject, 1f, espObject.RenderColor());

                if (configuration.HighlightPassage && type == ESPObject.ESPType.Passage)
                    DrawCircleFilled(drawList, espObject, 2f, espObject.RenderColor());
            }

            if (configuration.ShowMobViews &&
                (type == ESPObject.ESPType.Enemy || type == ESPObject.ESPType.Mimic) &&
                BattleNpcSubKind.Enemy.Equals((BattleNpcSubKind)espObject.GameObject.SubKind) &&
                !espObject.InCombat())
            {
                if (configuration.ShowPatrolArrow && espObject.IsPatrol())
                    DrawFacingDirectionArrow(drawList, espObject, Color.Red.ToUint(), 0.6f);

                if (espObject.Distance() <= 50)
                {
                    switch (espObject.AggroType())
                    {
                        case ESPObject.ESPAggroType.Proximity:
                            DrawCircle(drawList, espObject, espObject.AggroDistance(),
                                       configuration.NormalAggroColor, DefaultFilledOpacity);
                            break;
                        case ESPObject.ESPAggroType.Sound:
                            DrawCircle(drawList, espObject, espObject.AggroDistance(),
                                       configuration.SoundAggroColor, DefaultFilledOpacity);
                            DrawCircleFilled(drawList, espObject, espObject.GameObject.HitboxRadius,
                                             configuration.SoundAggroColor, DefaultFilledOpacity);
                            break;
                        case ESPObject.ESPAggroType.Sight:
                            DrawConeFromCenterPoint(drawList, espObject, espObject.SightRadian,
                                                    espObject.AggroDistance(), configuration.NormalAggroColor);
                            break;
                        default:
                            NecroLens.PluginLog.Error(
                                $"Unable to process AggroType {espObject.AggroType().ToString()}");
                            break;
                    }
                }
            }
        }
        catch (Exception e)
        {
            NecroLens.PluginLog.Error(e.ToString());
        }
    }

    /**
     * Method returns true if the ESP is Enabled, In valid state and in DeepDungeon
     */
    private bool ShouldDraw()
    {
        return configuration.EnableESP &&
               !(NecroLens.Condition[ConditionFlag.LoggingOut] ||
                 NecroLens.Condition[ConditionFlag.BetweenAreas] ||
                 NecroLens.Condition[ConditionFlag.BetweenAreas51]) &&
               DeepDungeonUtil.InDeepDungeon && clientState.LocalPlayer != null &&
               NecroLens.ClientState.LocalContentId > 0 && NecroLens.ObjectTable.Length > 0 &&
               !NecroLens.DeepDungeonService.FloorDetails.FloorTransfer;
    }

    /**
     * Not-Drawing Scanner method updating mapObjects every Tick.
     */
    private void MapScanner()
    {
        logger.LogDebug("ESP Background scan started");
        // Keep scanner alive until 'active' is set to false
        while (active)
        {
            try
            {
                if (GetShouldDrawFromMainThread())
                {
                    var entityList = new List<ESPObject>();
                    var waitHandle = new ManualResetEventSlim();

                    // Dispatch the object scanning onto the main thread
                    Framework.RunOnFrameworkThread(() =>
                    {
                        try
                        {
                            // Iterate over objects using the injected objectTable
                            foreach (var obj in objectTable)
                            {
                                // If the object is valid and not ignored, process it.
                                if (obj.IsValid() && !IsIgnoredObject(obj))
                                {
                                    MobInfo mobInfo = null;
                                    if (obj is IBattleNpc npcObj)
                                    {
                                        mobInfoService.MobInfoDictionary.TryGetValue(npcObj.NameId, out mobInfo);
                                    }

                                    // Create the ESPObject with all required dependencies
                                    var espObj = new ESPObject(obj, clientState, configuration, deepDungeonService, logger, mobInfo);

                                    // If it's a GoldChest with a double chest mapping, set its pomander value.
                                    if (obj.DataId == DataIds.GoldChest &&
                                        deepDungeonService.FloorDetails.DoubleChests.TryGetValue(obj.EntityId, out var value))
                                    {
                                        espObj.ContainingPomander = value;
                                    }

                                    // Allow the deep dungeon service to interact with the ESPObject
                                    deepDungeonService.TryInteract(espObj);
                                    entityList.Add(espObj);
                                    deepDungeonService.TrackFloorObjects(espObj);
                                }

                                // Also, if the object is the local player, add it separately.
                                if (clientState.LocalPlayer != null &&
                                    clientState.LocalPlayer.EntityId == obj.EntityId)
                                {
                                    entityList.Add(new ESPObject(obj, clientState, configuration, deepDungeonService, logger, null));
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            logger.LogError(ex.ToString());
                        }
                        finally
                        {
                            waitHandle.Set();
                        }
                    });
                    waitHandle.Wait();

                    // Update the shared mapObjects list in a thread-safe manner.
                    lock (mapObjects)
                    {
                        mapObjects.Clear();
                        mapObjects.AddRange(entityList);
                    }
                }
            }
            catch (Exception e)
            {
                logger.LogError(e.ToString());
            }

            // Sleep for the specified tick interval.
            Thread.Sleep(Tick);
        }
    }

    private bool GetShouldDrawFromMainThread()
    {
        bool shouldDraw = false;
        var waitHandle = new ManualResetEventSlim();
        framework.RunOnFrameworkThread(() =>
        {
            try
            {
                shouldDraw = ShouldDraw();
            }
            catch (Exception e)
            {
                logger.LogError(e.ToString());
            }
            finally
            {
                waitHandle.Set();
            }
        });
        waitHandle.Wait();
        return shouldDraw;
    }
}

