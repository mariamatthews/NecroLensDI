namespace NecroLens.Interface
{
    public interface ILoggingService
    {
        void LogError(string message);
        void LogDebug(string message);
        void Information(string message);
        void LogVerbose(string message);
    }
}
