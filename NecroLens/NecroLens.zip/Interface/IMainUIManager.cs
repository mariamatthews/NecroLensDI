namespace NecroLens.Interface
{
    public interface IMainUIManager
    {
        void ToggleMainUI();
        void ToggleConfigUI();
    }
}
